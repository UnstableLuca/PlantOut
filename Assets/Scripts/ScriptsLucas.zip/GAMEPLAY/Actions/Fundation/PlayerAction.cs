using UnityEngine;

public abstract class PlayerAction : ScriptableObject
{
    [Header("Datos Base de Acci�n")]
    public string actionName = "Nueva Acci�n";
    public string animationTrigger = "Attack";
    public float cooldown = 0.3f;

    public abstract void Execute(ActionContext context);
}