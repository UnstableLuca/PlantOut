using UnityEngine;

[System.Serializable]
public struct ActionContext
{
    public Fighter attacker;
    public Fighter target;
    public float damageMultiplier;
    public float speedMultiplier;

    public float CalculateFinalDamage(float baseDamage)
    {
        return baseDamage * Mathf.Max(0f, damageMultiplier);
    }
}