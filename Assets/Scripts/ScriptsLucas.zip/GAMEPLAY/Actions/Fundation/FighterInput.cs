using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Utilities;

[RequireComponent(typeof(Fighter))]
public class FighterInput : MonoBehaviour
{
    [Header("Esquema de controles")]
    [Tooltip("True = WASD | False = IJKL")]
    public bool isLeftPlayer = true;

    Fighter fighter;
    private InputActions inputActions;
    private InputAction meleeAction;
    private InputAction rangedAction;
    private InputAction blockAction;
    private InputAction skillAction;

    void Awake()
    {
        fighter = GetComponent<Fighter>();
        inputActions = new InputActions();

        InputActionMap combatMap = inputActions.asset.FindActionMap("Combat", throwIfNotFound: true);

        meleeAction = combatMap.FindAction("Melee");
        rangedAction = combatMap.FindAction("Ranged");
        blockAction = combatMap.FindAction("Block");
        skillAction = combatMap.FindAction("Skill");

        AssignDevices();
    }

    private void AssignDevices()
    {
        var gamepads = Gamepad.all;
        var keyboard = Keyboard.current;

        if (isLeftPlayer)
        {
            // Jugador Izquierda: Mando 0 (si existe) + Teclado (WASD)
            if (gamepads.Count >= 1 && keyboard != null)
                inputActions.devices = new ReadOnlyArray<InputDevice>(new InputDevice[] { gamepads[0], keyboard });
            else if (gamepads.Count >= 1)
                inputActions.devices = new ReadOnlyArray<InputDevice>(new InputDevice[] { gamepads[0] });
            else if (keyboard != null)
                inputActions.devices = new ReadOnlyArray<InputDevice>(new InputDevice[] { keyboard });
        }
        else
        {
            // Jugador Derecha: Mando 1 (si hay 2 mandos), Mando 0 (si solo hay 1 mando y J1 usa teclado) + Teclado (IJKL)
            if (gamepads.Count >= 2 && keyboard != null)
                inputActions.devices = new ReadOnlyArray<InputDevice>(new InputDevice[] { gamepads[1], keyboard });
            else if (gamepads.Count == 1 && keyboard != null)
                inputActions.devices = new ReadOnlyArray<InputDevice>(new InputDevice[] { gamepads[0], keyboard });
            else if (keyboard != null)
                inputActions.devices = new ReadOnlyArray<InputDevice>(new InputDevice[] { keyboard });
        }
    }

    void OnEnable()
    {
        inputActions.asset.FindActionMap("Combat").Enable();

        meleeAction.started += OnMeleeStarted;
        rangedAction.started += OnRangedStarted;

        blockAction.started += OnBlockStarted;
        blockAction.canceled += OnBlockCanceled;

        skillAction.started += OnSkillStarted;
        skillAction.canceled += OnSkillCanceled;
    }

    void OnDisable()
    {
        meleeAction.started -= OnMeleeStarted;
        rangedAction.started -= OnRangedStarted;

        blockAction.started -= OnBlockStarted;
        blockAction.canceled -= OnBlockCanceled;

        skillAction.started -= OnSkillStarted;
        skillAction.canceled -= OnSkillCanceled;

        inputActions.asset.FindActionMap("Combat").Disable();
    }

    void OnDestroy()
    {
        inputActions.Dispose();
    }
    private bool IsValidBindingForThisPlayer(InputAction.CallbackContext ctx)
    {
        if (ctx.control.device is Gamepad) return true;

        if (ctx.control.device is Keyboard)
        {
            string keyName = ctx.control.name.ToLower();
            bool isLeftKey = (keyName == "w" || keyName == "a" || keyName == "s" || keyName == "d");
            bool isRightKey = (keyName == "i" || keyName == "j" || keyName == "k" || keyName == "l");

            return isLeftPlayer ? isLeftKey : isRightKey;
        }

        return false;
    }

    #region Eventos
    private void OnMeleeStarted(InputAction.CallbackContext ctx)
    {
        if (!IsValidBindingForThisPlayer(ctx)) return;
        fighter.PerformMelee();
    }

    private void OnRangedStarted(InputAction.CallbackContext ctx)
    {
        if (!IsValidBindingForThisPlayer(ctx)) return;
        fighter.PerformRanged();
    }

    private void OnBlockStarted(InputAction.CallbackContext ctx)
    {
        if (!IsValidBindingForThisPlayer(ctx)) return;
        fighter.SetBlocking(true);
    }

    private void OnBlockCanceled(InputAction.CallbackContext ctx)
    {
        if (!IsValidBindingForThisPlayer(ctx)) return;
        fighter.SetBlocking(false);
    }

    private void OnSkillStarted(InputAction.CallbackContext ctx)
    {
        if (!IsValidBindingForThisPlayer(ctx)) return;
        fighter.PressSkill();
    }

    private void OnSkillCanceled(InputAction.CallbackContext ctx)
    {
        if (!IsValidBindingForThisPlayer(ctx)) return;
        fighter.ReleaseSkill();
    }
    #endregion
}