using UnityEngine;

public class PlantCharacterModule : MonoBehaviour
{
    [Header("Acciones b�sicas")]
    public PlayerAction meleeAsset;
    public PlayerAction rangedAsset;
    public PlayerAction blockAsset;

    [Header("Configuraci�n")]
    [Tooltip("Desmarcar solo en Belladona.")]
    public bool canGainStandardEnergy = true;

    [Header("Referencias")]
    public Animator modelAnimator;
    public Transform firePoint;
    public Transform stemTransform;

    public Fighter ParentFighter { get; private set; }

    void Start()
    {
        ParentFighter = GetComponentInParent<Fighter>();
        if (ParentFighter != null)
        {
            ParentFighter.RegisterCharacter(
                meleeAsset,
                rangedAsset,
                blockAsset,
                modelAnimator,
                firePoint,
                stemTransform,
                canGainStandardEnergy
                );

            if (!ParentFighter.isLeftPlayer)
            {
                Vector3 scale = transform.localScale;
                scale.x = -Mathf.Abs(scale.x);
                transform.localScale = scale;
            }
        }
        else
        {
            Debug.LogError($"[{name}] No se encontr� un componente Fighter en el objeto padre.");
        }
    }
}
