using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fighter : MonoBehaviour
{
    #region Variables
    [Header("Identidad y Combate")]
    public Fighter opponent;
    public bool isLeftPlayer = true;

    [Header("Estad�sticas Base")]
    public float maxHealth = 1000f;
    public float currentHealth;
    [Range(0, 5)] public int currentCharges = 0;
    public const int MAX_CHARGES = 5;

    [Tooltip("Desactivar en Rosaros, ya que solo recarga energ�a con el sol")]
    public bool canGainStandardEnergy = true;

    [Header("Bloqueo y Parry")]
    public float parryWindow = 0.25f;
    [Range(0f, 1f)] public float normalBlockReduction = 0.5f;
    public bool IsBlocking { get; private set; }
    private float blockStartTime = -10f;

    [Header("Multiplicadores Activos (Buffs/Debuffs)")]
    public float damageMultiplier = 1f;          // Ej: Pinchos de Spyke (x2, x4, x6) o Calor de Peasum
    public float damageDefenseMultiplier = 1f;   // Ej: Fr�o de Peasum (< 1f reduce da�o recibido)
    public float actionSpeedMultiplier = 1f;     // Ej: Ralentizaci�n por bichos o palillo de Arandino
    public bool isImmune = false;                // Ej: Belladona cargando 5 barras

    // Estado de Control de Masas
    public bool IsStunned { get; private set; }
    private float stunTimer = 0f;
    private float slowTimer = 0f;

    // Acciones Base (Inyectadas din�micamente por el Prefab hijo)
    private PlayerAction meleeAction;
    private PlayerAction rangedAction;
    private PlayerAction blockAction;

    // Referencias Visuales y de Spawns (Inyectadas din�micamente por el Prefab hijo)
    public Animator CharacterAnimator { get; private set; }
    public Transform FirePoint { get; private set; }
    public Transform StemTransform { get; private set; }

    // Eventos para UI, Animaciones y Scripts de Habilidades de Planta
    public event Action<float, float> OnHealthChanged;
    public event Action<int> OnChargesChanged;
    public event Action<float> OnDamageTaken;
    public event Action OnParrySuccess;
    public event Action OnBlockedHit;
    public event Action<int> OnSkillPressed;           // Al pulsar W / I (pasa cargas actuales)
    public event Action<int, float> OnSkillReleased;   // Al soltar W / I (pasa cargas y tiempo mantenido)

    private float skillHoldStartTime = 0f;
    private bool isHoldingSkill = false;
    #endregion

    #region Awake, Start & Update
    void Awake()
    {
        currentHealth = maxHealth;
    }

    void Start()
    {
        OnHealthChanged?.Invoke(currentHealth, maxHealth);
        OnChargesChanged?.Invoke(currentCharges);
    }

    void Update()
    {
        UpdateStatusTimers();
    }

    private void UpdateStatusTimers()
    {
        if (IsStunned)
        {
            stunTimer -= Time.deltaTime;
            if (stunTimer <= 0f)
            {
                IsStunned = false;
                if (CharacterAnimator != null) CharacterAnimator.SetBool("Stunned", false);
            }
        }

        if (slowTimer > 0f)
        {
            slowTimer -= Time.deltaTime;
            if (slowTimer <= 0f)
            {
                actionSpeedMultiplier = 1f;
            }
        }
    }
    #endregion

    #region Child Link
    public void RegisterCharacter(
        PlayerAction melee,
        PlayerAction ranged,
        PlayerAction block,
        Animator animator,
        Transform firePoint,
        Transform stemTransform,
        bool standardEnergyGain = true)
    {
        meleeAction = melee;
        rangedAction = ranged;
        blockAction = block;
        CharacterAnimator = animator;
        FirePoint = firePoint;
        StemTransform = stemTransform;
        canGainStandardEnergy = standardEnergyGain;

        PlantHeight heightSystem = GetComponent<PlantHeight>();
        if (heightSystem != null && stemTransform != null) heightSystem.SetStemTransform(stemTransform);
    }
    #endregion

    #region InputAction
    public bool CanAct()
    {
        return !IsStunned && currentHealth > 0f;
    }

    public void PerformMelee()
    {
        if (!CanAct() || IsBlocking || meleeAction == null) return;
        ExecuteAction(meleeAction);
    }

    public void PerformRanged()
    {
        if (!CanAct() || IsBlocking || rangedAction == null) return;
        ExecuteAction(rangedAction);
    }

    public void SetBlocking(bool active)
    {
        if (!CanAct() && active) return;

        if (active && !IsBlocking)
        {
            IsBlocking = true;
            blockStartTime = Time.time;
            if (CharacterAnimator != null) CharacterAnimator.SetBool("Blocking", true);
            if (blockAction != null) ExecuteAction(blockAction);
        }
        else if (!active && IsBlocking)
        {
            IsBlocking = false;
            if (CharacterAnimator != null) CharacterAnimator.SetBool("Blocking", false);
        }
    }

    public void PressSkill()
    {
        if (!CanAct() || IsBlocking) return;
        isHoldingSkill = true;
        skillHoldStartTime = Time.time;
        OnSkillPressed?.Invoke(currentCharges);
    }

    public void ReleaseSkill()
    {
        if (!isHoldingSkill) return;
        isHoldingSkill = false;
        float heldDuration = Time.time - skillHoldStartTime;
        OnSkillReleased?.Invoke(currentCharges, heldDuration);
    }

    private void ExecuteAction(PlayerAction action)
    {
        ActionContext context = new ActionContext
        {
            attacker = this,
            target = opponent,
            damageMultiplier = this.damageMultiplier,
            speedMultiplier = this.actionSpeedMultiplier
        };
        action.Execute(context);
    }
    #endregion

    #region Score, Energy, Parry & Altered States
    public void TakeDamage(float rawAmount, bool ignoreBlock = false, bool canBeParried = true)
    {
        if (currentHealth <= 0f || isImmune) return;

        float finalDamage = rawAmount * damageDefenseMultiplier;

        // Comprobaci�n de Bloqueo y Parry
        if (IsBlocking && !ignoreBlock)
        {
            bool isParry = canBeParried && (Time.time - blockStartTime <= parryWindow);
            if (isParry)
            {
                // Parry exitoso: anula el da�o y libera la guardia
                IsBlocking = false;
                if (CharacterAnimator != null) CharacterAnimator.SetBool("Blocking", false);
                OnParrySuccess?.Invoke();
                return;
            }
            else
            {
                finalDamage *= (1f - normalBlockReduction);
                OnBlockedHit?.Invoke();
            }
        }

        currentHealth = Mathf.Max(0f, currentHealth - finalDamage);
        OnHealthChanged?.Invoke(currentHealth, maxHealth);
        OnDamageTaken?.Invoke(finalDamage);

        if (CharacterAnimator != null && !IsBlocking)
        {
            CharacterAnimator.SetTrigger("Hit");
        }
    }

    public void Heal(float amount)
    {
        if (currentHealth <= 0f) return;
        currentHealth = Mathf.Min(maxHealth, currentHealth + amount);
        OnHealthChanged?.Invoke(currentHealth, maxHealth);
    }

    public void AddCharge(int amount = 1, bool bypassStandardRestriction = false)
    {
        if (!canGainStandardEnergy && !bypassStandardRestriction) return;
        currentCharges = Mathf.Clamp(currentCharges + amount, 0, MAX_CHARGES);
        OnChargesChanged?.Invoke(currentCharges);
    }

    public bool ConsumeCharges(int amount)
    {
        if (currentCharges < amount) return false;
        currentCharges -= amount;
        OnChargesChanged?.Invoke(currentCharges);
        return true;
    }

    public void ApplyStun(float duration)
    {
        if (isImmune) return;
        IsStunned = true;
        stunTimer = Mathf.Max(stunTimer, duration);
        IsBlocking = false;
        isHoldingSkill = false;
        if (CharacterAnimator != null) CharacterAnimator.SetBool("Stunned", true);
    }

    public void ApplySlow(float multiplier, float duration)
    {
        if (isImmune) return;
        actionSpeedMultiplier = multiplier;
        slowTimer = Mathf.Max(slowTimer, duration);
    }

    
    public Coroutine ApplyDamageOverTime(float damagePerSecond, float duration, float endBurstDamage = 0f)
    {
        return StartCoroutine(DamageOverTimeRoutine(damagePerSecond, duration, endBurstDamage));
    }

    private IEnumerator DamageOverTimeRoutine(float dps, float duration, float endBurstDamage)
    {
        float elapsed = 0f;
        while (elapsed < duration && currentHealth > 0f)
        {
            yield return new WaitForSeconds(1f);
            elapsed += 1f;
            TakeDamage(dps, ignoreBlock: true, canBeParried: false);
        }

        if (endBurstDamage > 0f && currentHealth > 0f)
        {
            TakeDamage(endBurstDamage, ignoreBlock: true, canBeParried: false);
        }
    }
    #endregion
}