using System.Runtime.CompilerServices;
using Unity.Cinemachine;
using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent (typeof(Collider))]
public class InteractableObject : MonoBehaviour
{
    [Header("Ajustes")]
    [SerializeField] private string interactionPrompt = "Interactuar";
    [SerializeField] private float interactionDistance = 4.0f;

    [Header("Camara")]
    [SerializeField] private CinemachineCamera vcamInteraction;

    [Header("Referencias")]
    [SerializeField] private DialogueAsset dialogueAsset;
    [SerializeField] private GameObject playerModel;

    private Outline outline;
    private bool playerIsNearby = false;
    private bool isInteracting = false;
    private Transform playerTransform;
    private PlayerMovement playerMovementScript;

    private InputActions inputActions;

    private void Awake()
    {
        outline = GetComponent<Outline>();
        if (outline != null) outline.enabled = false;

        /*Collider col = GetComponent<Collider>();
        col.isTrigger = true;*/

        inputActions = new InputActions();
    }

    private void OnEnable()
    {
        inputActions.Plaza.Enable();
        inputActions.Plaza.Interact.performed += OnInteractPressed;
    }

    private void OnDisable()
    {
        inputActions.Plaza.Interact.performed -= OnInteractPressed;
        inputActions.Plaza.Disable();
    }

    private void Start()
    {
        GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
        if (playerObj != null)
        {
            playerTransform = playerObj.transform;
            playerMovementScript = playerObj.GetComponent<PlayerMovement>();
        }
        else Debug.LogWarning("No se encontr� ning�n objeto con la Tag 'Player' en la escena.");
    }

    private void Update()
    {
        if (playerTransform == null || isInteracting) return;
        
        float distance = Vector3.Distance(transform.position, playerTransform.position);

        bool previousState = playerIsNearby;
        playerIsNearby = distance <= interactionDistance;

        if (playerIsNearby != previousState)
        {
            if (outline != null)
            {
                outline.enabled = playerIsNearby;
            }
        }
    }

    private void OnInteractPressed(InputAction.CallbackContext context)
    {
        if (playerIsNearby && !isInteracting && dialogueAsset != null)
        {
            StartInteraction();
        }
    }

    private void StartInteraction()
    {
        isInteracting = true;

        if (DialogueManager.Instance != null)
        {
            DialogueManager.Instance.StartDialogue(dialogueAsset, vcamInteraction, playerModel, playerMovementScript, this);
        }
    }

    public void NotifyInteractionEnded()
    {
        isInteracting = false;
    }
}
