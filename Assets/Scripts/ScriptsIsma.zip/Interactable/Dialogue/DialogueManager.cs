using System.Collections;
using TMPro;
using Unity.Cinemachine;
using UnityEngine;
using UnityEngine.InputSystem;

public class DialogueManager : MonoBehaviour
{
    [Header("Referencias")]
    [SerializeField] private GameObject dialoguePanel;
    [SerializeField] private TextMeshProUGUI speakerNameText;
    [SerializeField] private TextMeshProUGUI dialogueText;

    [Header("Audio")]
    [SerializeField] private AudioSource audioSource;

    private DialogueAsset currentDialogue;
    private int currentLineIndex = 0;
    private bool isTyping = false;
    private Coroutine typingCoroutine;

    private CinemachineCamera activeInteractionCamera;
    private GameObject currentPlayerModel;
    private PlayerMovement playerMovementScript;
    private InteractableObject currentInteractable;

    private InputActions inputActions;

    private static DialogueManager instance;
    public static DialogueManager Instance => instance;

    private void OnEnable()
    {
        inputActions.Plaza.Enable();
        inputActions.Plaza.DialogueSkip.performed += OnSkipPressed;
    }

    private void OnDisable()
    {
        inputActions.Plaza.DialogueSkip.performed -= OnSkipPressed;
        inputActions.Plaza.Disable();
    }

    private void Awake()
    {
        if (instance == null) instance = this;
        else Destroy(gameObject);

        if (dialoguePanel != null) dialoguePanel.SetActive(false);
    }

    private void OnSkipPressed(InputAction.CallbackContext context)
    {
        Debug.Log("dadaaada");
        ShowCurrentLine();
    }

    public void StartDialogue(DialogueAsset dialogue, CinemachineCamera interactionCam, GameObject playerModel, PlayerMovement movementScript, InteractableObject interactable)
    {
        if (dialogue == null || dialogue.dialogueLines.Length == 0) return;
        
        currentDialogue = dialogue;
        currentLineIndex = 0;
        activeInteractionCamera = interactionCam;
        currentPlayerModel = playerModel;
        playerMovementScript = movementScript;
        currentInteractable = interactable;

        if (currentPlayerModel != null) currentPlayerModel.SetActive(false);
        if (playerMovementScript != null) playerMovementScript.enabled = false;

        if (activeInteractionCamera != null) activeInteractionCamera.Priority = 30;

        if (dialoguePanel != null) dialoguePanel.SetActive(false);

        ShowCurrentLine();
    }

    private void ShowCurrentLine()
    {
        if (currentLineIndex < currentDialogue.dialogueLines.Length)
        {
            var line = currentDialogue.dialogueLines[currentLineIndex];

            if (speakerNameText != null) speakerNameText.text = line.speakerName;

            float speed = 0.05f;
            float pitch = 1.0f;
            AudioClip[] sounds = null;

            if(line.linePersonality != null)
            {
                speed = line.linePersonality.textSpeed;
                pitch = line.linePersonality.basePitch;
                sounds = line.linePersonality.typingSounds;
            }

            if (typingCoroutine != null) StopCoroutine(typingCoroutine);
            typingCoroutine = StartCoroutine(TypeSentence(line.sentence, speed, pitch, sounds));
        }
        else EndDialogue();
    }

    private IEnumerator TypeSentence(string sentence, float speed, float pitch, AudioClip[] sounds)
    {
        isTyping = true;
        dialogueText.text = "";

        foreach (char letter in sentence.ToCharArray())
        {
            dialogueText.text += letter;

            if (sounds != null && sounds.Length > 0 && audioSource != null && !char.IsWhiteSpace(letter))
            {
                AudioClip randomClip = sounds[Random.Range(0, sounds.Length)];
                if (randomClip != null)
                {
                    float pitchVariation = Random.Range(0.9f, 1.1f);
                    audioSource.pitch = pitch * pitchVariation;
                    audioSource.PlayOneShot(randomClip);
                }
            }

            yield return new WaitForSeconds(speed);
        }

        isTyping = false;
    }

    public void DisplayNextLine()
    {
        if (isTyping)
        {
            StopCoroutine(typingCoroutine);
            dialogueText.text = currentDialogue.dialogueLines[currentLineIndex].sentence;
            isTyping = false;
        }
        else
        {
            currentLineIndex++;
            ShowCurrentLine();
        }
    }

    public void EndDialogue()
    {
        if (dialoguePanel != null) dialoguePanel.SetActive(false);

        if (activeInteractionCamera != null) activeInteractionCamera.Priority = 5;

        if (currentPlayerModel != null) currentPlayerModel.SetActive(true);
        if (playerMovementScript != null) playerMovementScript.enabled = true;

        if (currentInteractable != null)
        {
            currentInteractable.NotifyInteractionEnded();
            currentInteractable = null;
        }

        currentDialogue = null;
    }
}
